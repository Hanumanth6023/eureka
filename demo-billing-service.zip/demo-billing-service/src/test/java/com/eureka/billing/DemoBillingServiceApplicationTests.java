package com.eureka.billing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoBillingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
